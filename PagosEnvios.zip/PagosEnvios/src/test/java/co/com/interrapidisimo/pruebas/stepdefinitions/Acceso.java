package co.com.interrapidisimo.pruebas.stepdefinitions;

import co.com.interrapidisimo.pruebas.interactions.Config;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.serenitybdd.screenplay.actions.Open;
import net.serenitybdd.screenplay.actors.Cast;
import net.serenitybdd.screenplay.actors.OnStage;
import net.thucydides.core.annotations.Managed;
import org.openqa.selenium.WebDriver;

import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class Acceso {
    @Before
    public void Begin() {
        OnStage.setTheStage(Cast.whereEveryoneCan(BrowseTheWeb.with(TheirBrowse)));
        OnStage.theActorCalled("Gustavo");
    }

    @Managed
    private WebDriver TheirBrowse;

    @Given("^Apertura de navegador \"([^\"]*)\"$")
    public void aperturaDeNavegador(String ambiente) {
        String url;
        if ("api".equalsIgnoreCase(ambiente)) {
            url = Config.getApiUrl();
        } else {
            url = Config.getQaUrl(); // por defecto a QA
        }
        theActorInTheSpotlight().wasAbleTo(Open.url(url));
    }
}
