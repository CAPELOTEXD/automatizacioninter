package co.com.interrapidisimo.pruebas.stepdefinitions;

import cucumber.api.java.en.Given;

public class MyStepdefs {
    @Given("^busca google$")
    public void buscaGoogle() {

    }
}
