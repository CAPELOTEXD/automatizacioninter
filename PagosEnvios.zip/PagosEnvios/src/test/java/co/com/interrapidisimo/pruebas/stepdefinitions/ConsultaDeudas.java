package co.com.interrapidisimo.pruebas.stepdefinitions;

import co.com.interrapidisimo.pruebas.questions.ingresoDeudas;
import co.com.interrapidisimo.pruebas.tasks.ConsultarDeudas;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.GivenWhenThen;
import net.serenitybdd.screenplay.actors.OnStage;

import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;

public class ConsultaDeudas {

    Actor actor = OnStage.theActorInTheSpotlight();
    @When("^ingresa el (.+) y (.+)$")
    public void ingresaElUSUARIOYTELEFONO(String usuario, String telefono) {
        actor.attemptsTo(new ConsultarDeudas(usuario, telefono));
    }

    @Then("^podra ver sus deudas (.+)$")
    public void podraVerSusDeudas(String mensaje) {
        theActorInTheSpotlight().should(
                GivenWhenThen.seeThat(ingresoDeudas.verify(mensaje))
        );
    }
}
