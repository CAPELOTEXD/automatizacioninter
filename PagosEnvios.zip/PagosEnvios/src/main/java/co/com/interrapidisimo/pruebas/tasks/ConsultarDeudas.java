package co.com.interrapidisimo.pruebas.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.EnterValue;
import net.serenitybdd.screenplay.waits.WaitUntil;
import net.serenitybdd.screenplay.waits.WaitUntilAngularIsReady;

import static co.com.interrapidisimo.pruebas.userinterfases.inicioPagos.*;

public class ConsultarDeudas implements Task {
    private String usuario;
    private String telefono;

    public ConsultarDeudas(String usuario, String telefono) {
        this.usuario = usuario;
        this.telefono = telefono;
    }


    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                WaitUntil.angularRequestsHaveFinished(),
                Enter.theValue(usuario).into(CEDULA),
                Enter.theValue(telefono).into(TELEFONO),
                Click.on(BTN_IR)
        );
    }
}
