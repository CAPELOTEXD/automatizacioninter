package co.com.interrapidisimo.pruebas.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.waits.WaitUntil;
import net.serenitybdd.screenplay.matchers.WebElementStateMatchers;

import static co.com.interrapidisimo.pruebas.userinterfases.ListaEnvios.TIT_PENDIENTES;

public class ingresoDeudas implements Question<Boolean> {
    private final String expectedMessage;

    public ingresoDeudas(String expectedMessage) {
        this.expectedMessage = expectedMessage;
    }

    public static ingresoDeudas verify(String expectedMessage) {
        return new ingresoDeudas(expectedMessage);
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        // Espera a que el elemento sea visible
        actor.attemptsTo(
                WaitUntil.the(TIT_PENDIENTES, WebElementStateMatchers.isVisible()).forNoMoreThan(20).seconds()
        );

        // Obtiene el texto del elemento
        String actualMessage = TIT_PENDIENTES.resolveFor(actor).getText().trim();

        // Debugging: imprime el mensaje esperado y el actual
        System.out.println("Mensaje esperado: '" + expectedMessage + "'");
        System.out.println("Mensaje actual: '" + actualMessage + "'");

        // Compara el mensaje esperado con el actual
        return expectedMessage.equals(actualMessage);
    }
}
