package co.com.interrapidisimo.pruebas.interactions;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Config  {
    private static Properties properties = new Properties();

    static {
        try (InputStream input = Config.class.getClassLoader().getResourceAsStream("Enlaces.properties")) {
            if (input == null) {
                System.out.println("Lo siento, no se pudo encontrar el archivo de propiedades");
                // Aquí puedes lanzar una excepción si prefieres manejarlo de esa manera
                throw new IllegalArgumentException("El archivo de propiedades no fue encontrado.");
            }
            properties.load(input);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public static String getApiUrl() {
        return properties.getProperty("api.url");
    }

    public static String getQaUrl() {
        return properties.getProperty("qa.url");
    }
}

