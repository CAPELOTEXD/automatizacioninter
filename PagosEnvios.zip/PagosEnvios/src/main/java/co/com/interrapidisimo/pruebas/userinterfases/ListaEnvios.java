package co.com.interrapidisimo.pruebas.userinterfases;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class ListaEnvios {

    public static final Target TIT_PENDIENTES = Target.the("por pagar")
            .located(By.xpath("//span[contains(text(),'por pagar')]"));
    public static final Target GUIA = Target.the("Guia a validar")
            .located(By.xpath("//span[contains(text(),'Envíos pendientes')]"));
}
