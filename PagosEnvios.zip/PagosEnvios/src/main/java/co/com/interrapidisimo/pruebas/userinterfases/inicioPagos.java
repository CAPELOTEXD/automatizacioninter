package co.com.interrapidisimo.pruebas.userinterfases;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class inicioPagos {
    public static final Target CEDULA = Target.the("Cedula")
            .located(By.xpath("//input[@id='identificacion']"));

    public static final Target TELEFONO = Target.the("Telefono")
            .located(By.xpath("//input[@id='telefono']"));
    public static final Target BTN_IR = Target.the("BTN_IR")
            .located(By.xpath("//button[@type='submit']"));
}
